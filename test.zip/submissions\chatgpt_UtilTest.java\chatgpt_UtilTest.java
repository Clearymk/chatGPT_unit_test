import org.junit.Test;
import static org.junit.Assert.*;

public class UtilTest {

    @Test
    public void testStripLeadingAndTrailingQuotes() {
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two\""));
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two"));
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("one two\""));
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("one two"));
    }

    @Test
    public void testStripLeadingHyphens() {
        assertEquals("one two", Util.stripLeadingHyphens("--one two"));
        assertEquals("one two", Util.stripLeadingHyphens("-one two"));
        assertEquals("one two", Util.stripLeadingHyphens("one two"));
        assertNull(Util.stripLeadingHyphens(null));
    }
}
